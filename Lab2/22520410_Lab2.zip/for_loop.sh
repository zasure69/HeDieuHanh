#!/bin/sh
for foo in bar fud 13
do
    echo $foo
done
exit 0